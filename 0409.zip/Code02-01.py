a = 300
b = 200
result = a + b
print(a, '+', b, '=', result)
result = a - b
print(a, '-', b, '=', result)
result = a * b
print(a, '*', b, '=', result)
result = a + b
print(a, '+', b, '=', result)
result = a / b
print(a, '/', b, '=', result)

a = 200
b = 200
result = a + b
print(a, '+', b, '=', result)
