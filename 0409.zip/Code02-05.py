import turtle



turtle.shape('turtle')
turtle.speed(3)

#메인 코드 부분
turtle.color("blue")

turtle.begin_fill()


turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.end_fill()
turtle.hideturtle()


turtle.forward(200)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.right(90)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.right(90)
turtle.right(90)
turtle.right(90)
turtle.forward(200)
turtle.forward(200)
turtle.back(90)
turtle.backward(90)
turtle.backward(10)

turtle.forward(200)
turtle.forward(200)



turtle.forward(200)
turtle.forward(200)
turtle.right(200)
turtle.forward(200)
turtle.right(200)
turtle.forward(200)
turtle.right(200)
turtle.forward(200)
turtle.right(200)
turtle.forward(200)
turtle.right(200)
turtle.forward(200)
turtle.right(200)
turtle.forward(100)
turtle.forward(200)
turtle.forward(200)
turtle.forward(200)



turtle.done()
