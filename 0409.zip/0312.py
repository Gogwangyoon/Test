Python 3.13.2 (tags/v3.13.2:4f8bb39, Feb  4 2025, 15:23:48) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("Hello, world")
Hello, world
>>> 10+20
30
>>> 6*2-2+2/2
11.0
>>> 6/2*2
6.0
>>> 6/2+2*2
7.0
>>> print("love"
...       )
love
>>> or(1)
SyntaxError: invalid syntax
>>> or("0")
SyntaxError: invalid syntax
>>> a=100
>>> b=50
>>> result=a+b
>>> print(result)
150
>>> print(a, '+', b,'=', result)
100 + 50 = 150
>>> print(a, '-', b,'=', result)
100 - 50 = 150
>>> print(a, '-', b,'=', result)
100 - 50 = 150
>>> print(a, "-", b,'=', result)
100 - 50 = 150
>>> print(a, '/', b,'=', result)
100 / 50 = 150
>>> 
>>> print(a, '+', b,'=', result);
100 + 50 = 150
>>> print(a, '-', b,'=', result);
100 - 50 = 150
>>> resut=a+b
>>> print(a, '-', b,'=', result);
100 - 50 = 150
>>> print(result)
150
