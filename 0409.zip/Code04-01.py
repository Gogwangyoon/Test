''' a = 5; b = 3
print(a + b, a - b, a * b, a / b, a // b, a % b, a ** b, '\n') '''

''' s1,s2,s3="100","100.123","999999"
print(int(s1) + 1, float(s2) + 1,int(s3) + 1) ''' 

''' a = 100; b = 100.123 ### 출력 안 됨
str(a) + '1'; str(b) + '1' '''

'''
money, c50000, c100, c50, c10 = 0, 0, 0, 0, 0

money = int(input("교환할 돈은 얼마? "))

c50000 = money // 50000
money %= 50000

c100 = money // 100
money %= 100

c50 = money // 50
money %= 50

c10 = money // 10
money %= 10

print("\n 500원짜리 ==> %d개" % c50000)
print("\n 100원짜리 ==> %d개" % c100)
print("\n 50원짜리 ==> %d개" % c50)
print("\n 10원짜리 ==> %d개" % c10)
print(" 바꾸지 못한 잔돈 ==> %d원\n" % money)'''

'''a, b=100,200
print(a==b,a!=b,a>b,a<b,a>=b,a<=b)
print(a+1, a+b+1)'''
