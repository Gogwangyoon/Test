##
'''for i in range(0, 3, 1):
    for k in range(0, 2, 1):
        print(" 파이썬 (i값 : %d , k값 : %d) "% (i, k))'''
##
'''k = 0

for i in range(2, 10, 2):
    print("## %d단 ##"% i)
    for k in range(1, 10, 1):
        print("%d X %d = %2d" % (i, k, i *k))
    print("")
print("\n")'''
##
line = ""

for i in range(9, 1, -1):
    line += ("# %d단 #" % i)
print(line)

for i in range(9, 0, -1):
    line = ""
    for k in range(9, 1, -1):
        line += ("%2dX %2d= %2d" % (k, i, k * i))
    print(line)
