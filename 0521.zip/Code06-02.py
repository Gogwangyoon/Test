'''for i in [0, 1, 2, 3] :
    print("%d: 하이")

print("\n")'''
##
'''for _ in(1, 7, 1, 2) :
    print("%d: hi")
print("\n")'''
##
'''for _ in range(0, 7, 1) :
    print("%d: hi")
print("\n")'''
##
'''for _ in range(2, -2, -1) :
    print("%d: lo"%_)
print("\n")'''
##
'''for _ in range(1, 6, 1) :
    print("%d "%_, end= " ")
print("\n")'''
##
'''hap = 0
for i in range (1, 11, 1):
    hap += i
print("1부터 10까지의 합계 : %d"% hap)
print("\n")

for _ in range(1, 11, 1) :
    print("%d: hi"%_)
print("\n")'''
##

'''hap = 0
for i in range (7, 101, 7):
    hap += i
print("0과 100 사이에 있는 7의 배수  합계 : %d"% hap)
print("\n")'''
##


'''hap = 0
num = 0

num = int(input("값을 입력하세요 :"))

for i in range(1, num+1, 1):
    hap += i

print("1에서 %d까지의 합계: %d"% (num, hap))
print("\n")'''
##

'''hap = 0
num1, num2, num3 = 0, 0, 0

num1 = int(input("시작값을 입력하세요 :"))
num2 = int(input("끝값을 입력하세요 :"))
num3 = int(input("증가값을 입력하세요 :"))

for i in range(num1, num2+1, num3):
    hap += i

print("%d에서 %d까지 %d씩 증가시킨 값의  합계: %d"% (num1, num2, num3, hap))
print("\n")'''
##
'''dan = 0
dan = int(input("단을 입력하세요 : "))

for i in range(1, 10, 1) :
    print("%d X %d = %2d" % (dan, i, dan*i))
print("\n")'''
##
i = 0
i = int(input("단을 입력하세요 : "))

for dan in range(9, 0, -1) :
    print("%d X %d = %2d" % (dan, i, dan*i))
    
    
print("\n")
##

##
