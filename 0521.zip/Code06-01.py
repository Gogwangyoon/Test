for _ in range(100, -101, -10) :
    print("%d : Hello"% _)
