s = int(input("점수를 입력하세요 : "))
a = ""

if s >= 90:
    a = "A"
elif s >= 85:
    a = "B+"
elif s >= 80:
    a = "B0"
elif s >= 70:
    a = "C"
elif s >= 60:
    a = "D"
elif s <= 59:
    a = "F"

print(a + " 학점입니다.")
