score = int(input("점수를 입력하세요 : "))

if score >= 90 :
    print("A 학점입니다.")
elif score >= 80 :
    print("B 학점입니다.")
elif score >= 80 :
    print("C 학점입니다.")
elif score >= 60 :
    print("D 학점입니다.")
else :
    print("F 학점입니다.")
